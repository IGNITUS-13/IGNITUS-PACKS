// Sombras del terreno: tinte solar cálido y sombras ricas con oclusión ambiental simulada.

const SHADE_TINT = vec3f(0.58, 0.66, 0.84);          // Sombra ambiental teñida por el cielo
const SUN_TINT = vec3f(1.10, 1.04, 0.93);            // Luz directa del sol limpia y cálida
const GOLDEN_SHADE_TINT = vec3f(0.50, 0.56, 0.82);   // Sombra crepuscular índigo/azulada
const GOLDEN_SUN_TINT = vec3f(1.22, 0.92, 0.65);     // Luz dorada al atardecer

const SHADE_FROM = -0.15;
const SUN_FROM = 0.30;
const SHADOW_DEBUG = false;

fn shadeTint() -> vec3f {
    return mix(SHADE_TINT, GOLDEN_SHADE_TINT, goldenHour());
}

fn sunTint() -> vec3f {
    return mix(SUN_TINT, GOLDEN_SUN_TINT, goldenHour());
}

fn sunFaceTint(normal: vec3f) -> vec3f {
    let sunDir = bloxdSunDirection();
    let facing = smoothstep(SHADE_FROM, SUN_FROM, dot(normal, sunDir));
    if (SHADOW_DEBUG) {
        return mix(vec3f(0.4, 0.4, 1.0), vec3f(1.0, 0.4, 0.4), facing);
    }
    let ao = ambientOcclusionDirectional(normal);
    let baseTint = mix(shadeTint() * ao, sunTint(), facing);
    return mix(vec3f(1.0), baseTint, sunStrength());
}

fn bloxdTerrainLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    let sunDir = bloxdSunDirection();
    let facing = smoothstep(SHADE_FROM, SUN_FROM, dot(light.normal, sunDir));
    var strength = sunStrength();

    // Atenuación en interiores y bajo luces artificiales
    strength *= smoothstep(0.35, 0.88, light.skyLight);
    strength *= 1.0 - smoothstep(0.35, 0.88, maxComponent(max(light.blockLight, light.heldLight)));

    // Si la cara mira al sol pero la vertical del cielo está bloqueada (sombra proyectada):
    let skyReach = sunExposure(light.skyLight);
    let blocked = facing * (1.0 - skyReach) * strength;

    // Oclusión ambiental sutil en las zonas en sombra
    let ao = ambientOcclusionDirectional(light.normal);
    let shadowColorFactor = (shadeTint() / sunTint()) * mix(ao, 1.0, skyReach);

    let shaded = light.litColour * mix(vec3f(1.0), shadowColorFactor, blocked);

    var out = bloxdDefaultLight(surface, light);
    out.colour = bloxdApplyFog(brighten(shaded) + surface.emission, light);
    return out;
}