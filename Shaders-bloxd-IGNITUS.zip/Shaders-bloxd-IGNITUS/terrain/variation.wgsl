// Terrain surface hook: texture variation, and the sun-side shade from sunShade.wgsl. Texture variation: a slight, world-fixed brightness offset per block and per 8x8 shading cell, so large areas of one
// block don't look stamped. A surface hook, so it only recolours and runs in strict games too.

const BLOCK_VARIATION = 0.03;   // the most a block's brightness is moved either way
const CELL_VARIATION = 0.02;    // and each cell's, on top

fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    let block = bloxdFaceBlock(surface.position, surface.normal);
    // Half a cell inside the face, so the face's own block decides, not the one beside it.
    let cell = vec3i(floor(surface.position * f32(CELLS_PER_BLOCK) - surface.normal * 0.5))
        + bloxdOriginOffset() * CELLS_PER_BLOCK;
    let offset = (hashUnit(cellHash(block)) * 2.0 - 1.0) * BLOCK_VARIATION
        + (hashUnit(nextHash(cellHash(cell))) * 2.0 - 1.0) * CELL_VARIATION;

    var out = bloxdDefaultSurface(surface);
    out.colour = surface.colour * (1.0 + offset) * sunFaceTint(surface.normal);
    return out;
}
