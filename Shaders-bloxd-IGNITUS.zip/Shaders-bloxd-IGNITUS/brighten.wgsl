// A gentle brightness lift, applied by both light hooks to the lit colour before fog. It raises darks and mid-tones
// and leaves white at white, so bright blocks don't clip: about +15% at 0.2, +9% at 0.5 and nothing at 1.

const BRIGHTEN = 1.2;   // 1 leaves colour as it is; the slope at black

fn brighten(colour: vec3f) -> vec3f {
    let lifted = max(colour, vec3f(0.0));
    return lifted * BRIGHTEN / (1.0 + lifted * (BRIGHTEN - 1.0));
}
