// Shader de agua principal: paleta tropical, ondas fluidas y destellos de diamante

const WATER_BASE_COLOR = vec3f(0.5, 0.5, 0.8);
const WATER_ALPHA      = 0.9;

// Colores personalizados estilo Caribe/Zafiro
const WATER_SHALLOW = vec3f(0.16, 0.85, 0.86);   // Turquesa cristalino en la orilla
const WATER_MID     = vec3f(0.07, 0.48, 0.76);   // Azul vivo medio
const WATER_DEEP    = vec3f(0.02, 0.14, 0.42);   // Azul zafiro profundo

const OPACITY_SHALLOW = 0.40;                    // Gran transparencia costera
const OPACITY_DEEP    = 0.92;                    // Opaco en lo hondo
const DEPTH_FADE      = 5.2;

const SKY_REFLECT_COLOR    = vec3f(0.70, 0.86, 1.0);
const SUNSET_REFLECT_COLOR = vec3f(1.0, 0.65, 0.40);
const SUN_GLINT_COLOR      = vec3f(1.0, 0.98, 0.90);
const SPARKLE_COLOR        = vec3f(1.0, 1.0, 1.0);
const FOAM_COLOR           = vec3f(0.92, 0.98, 1.0);

const WAVE_DETAIL_FROM = 24.0;
const WAVE_DETAIL_TO   = 48.0;

struct WaterShade {
    depthFade: f32,
    waveHeight: f32,
    fresnel: f32,
    glint: f32,
    sparkle: f32,
    foam: f32,
}
var<private> shade: WaterShade;

fn waterShade(surface: BloxdSurfaceIn) -> WaterShade {
    let localCell = floor(surface.position * f32(CELLS_PER_BLOCK) - surface.normal * 0.5);
    let cellCentre = (localCell + 0.5) / f32(CELLS_PER_BLOCK);
    let eyeVec = bloxdEyePosition() - cellCentre;
    let eyeDist = max(length(eyeVec), 1e-4);
    let toEye = eyeVec / eyeDist;

    let detail = 1.0 - smoothstep(WAVE_DETAIL_FROM, WAVE_DETAIL_TO, eyeDist);
    let cellCoord = vec3i(localCell).xz + bloxdOriginOffset().xz * CELLS_PER_BLOCK;
    let wave = waveField(cellCoord, detail);

    // Normal calculada a partir de las nuevas ondas
    let upness = clamp(surface.normal.y, 0.0, 1.0);
    let waveNormal = normalize(vec3f(wave.x, 1.0, wave.y));
    let shadeNormal = normalize(mix(surface.normal, waveNormal, upness * 0.85));

    // Reflejo Fresnel
    let grazing = 1.0 - clamp(dot(toEye, shadeNormal), 0.0, 1.0);
    let fresnel = 0.03 + 0.97 * pow(grazing, 4.0);

    // Reflejo solar (estela satinada)
    let sunDir = bloxdSunDirection();
    let sunUp = clamp(sunDir.y * 3.5, 0.0, 1.0);
    let halfVector = normalize(toEye + sunDir);
    let nDotH = clamp(dot(shadeNormal, halfVector), 0.0, 1.0);
    let glint = (pow(nDotH, 150.0) * 0.65 + pow(nDotH, 24.0) * 0.12) * sunUp;

    // Destellos nuevos desde sparkle.wgsl
    let sparkle = waterSparkle(localCell, sunUp, upness);

    // Profundidad de agua
    let behind = bloxdOpaqueBehind();
    let thickness = select(DEPTH_FADE, max(surface.position.y - behind.position.y, 0.0), behind.found);
    let depthFraction = clamp(thickness / DEPTH_FADE, 0.0, 1.0);
    let depthFade = 1.0 - exp(-2.6 * depthFraction);

    // Espuma suave en la orilla
    let foam = (1.0 - smoothstep(0.04, 0.60, thickness)) * smoothstep(-0.1, 0.5, wave.z) * step(0.5, upness);

    return WaterShade(depthFade, wave.z, fresnel, glint, sparkle, foam);
}

fn bloxdLiquidSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    shade = waterShade(surface);

    var out = bloxdDefaultSurface(surface);
    out.colour = surface.colour / WATER_BASE_COLOR;

    let baseAlpha = mix(OPACITY_SHALLOW, OPACITY_DEEP, shade.depthFade);
    out.alpha = clamp(
        (surface.alpha / WATER_ALPHA) * baseAlpha * mix(0.9, 1.25, shade.fresnel)
        + shade.glint * 0.45 + shade.sparkle * 0.25 + shade.foam * 0.15,
        0.0, 1.0
    );
    return out;
}

fn bloxdLiquidLight(surface: BloxdSurface, light: BloxdLightIn) -> BloxdLight {
    let skyExposure = smoothstep(0.35, 0.95, light.skyLight);
    let sunReach = sunExposure(light.skyLight);

    // Gradiente de 3 fases de profundidad
    var waterCol = mix(WATER_SHALLOW, WATER_MID, smoothstep(0.0, 0.45, shade.depthFade));
    waterCol = mix(waterCol, WATER_DEEP, smoothstep(0.45, 1.0, shade.depthFade));

    var col = light.litColour * waterCol;
    col *= 1.0 + shade.waveHeight * 0.04;

    // Reflejo del cielo
    let skyReflect = mix(SKY_REFLECT_COLOR, SUNSET_REFLECT_COLOR, goldenHour());
    col = mix(col, light.skyLightColour * skyReflect, shade.fresnel * 0.58 * skyExposure);

    // Destellos solares, brillo de diamante y espuma
    col += shade.glint * sunReach * light.skyLightColour * SUN_GLINT_COLOR;
    col = mix(col, light.skyLightColour * SPARKLE_COLOR, shade.sparkle * sunReach);
    col = mix(col, light.litColour * FOAM_COLOR, shade.foam * 0.40);

    var out = bloxdDefaultLight(surface, light);
    out.colour = bloxdApplyFog(brighten(col) + surface.emission, light);
    return out;
}