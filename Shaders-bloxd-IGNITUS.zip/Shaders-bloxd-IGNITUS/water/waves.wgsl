// Sistema de olas dinámicas personalizadas con derivadas analíticas continuas
const CELLS_PER_BLOCK = 8;

// Olas compuestas con desplazamiento de corriente
fn waveField(cell: vec2i, detail: f32) -> vec3f {
    let worldPos = (vec2f(cell) + 0.5) / f32(CELLS_PER_BLOCK);
    let time = bloxdTime() * 1.5;

    // Tres direcciones de viento distintas para crear choque de corrientes natural
    let dir1 = vec2f(0.85, 0.52);
    let dir2 = vec2f(-0.54, 0.84);
    let dir3 = vec2f(0.28, -0.96);

    // Fases y frecuencias
    let phase1 = dot(worldPos, dir1) * 1.8 + time * 1.4;
    let phase2 = dot(worldPos, dir2) * 3.4 - time * 1.8;
    let phase3 = dot(worldPos, dir3) * 6.2 + time * 2.8;

    let c1 = cos(phase1);
    let c2 = cos(phase2);
    let c3 = cos(phase3);

    // Derivadas analíticas para una inclinación de onda suave
    let dSlope1 = dir1 * c1 * 0.055;
    let dSlope2 = dir2 * c2 * (0.032 * detail);
    let dSlope3 = dir3 * c3 * (0.016 * detail);

    let slope = -(dSlope1 + dSlope2 + dSlope3);
    let height = sin(phase1) * 0.5 + sin(phase2) * (0.3 * detail) + sin(phase3) * (0.2 * detail);

    return vec3f(slope, height);
}