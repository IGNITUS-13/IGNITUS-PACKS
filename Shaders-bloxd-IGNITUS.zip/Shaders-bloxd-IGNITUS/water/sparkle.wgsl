// Destellos finos y brillantes (Diamond Glint) sobre el agua
const TAU             = 6.2831853; // Constante matemática para ciclos completos
const SPARKLE_DENSITY = 0.045;     // Densidad de destellos en la estela solar
const SPARKLE_SHINE   = 0.95;      // Brillo máximo del destello
const SPARKLE_SPEED   = 2400.0;    // Velocidad de titileo suave

fn waterSparkle(localCell: vec3f, sunUp: f32, upness: f32) -> f32 {
    if (sunUp <= 0.0 || upness < 0.5) {
        return 0.0;
    }

    let eyePos = bloxdEyePosition();
    let cellCentre = (localCell + 0.5) / f32(CELLS_PER_BLOCK);
    let toEye = normalize(eyePos - cellCentre);

    // Alineación directa con el sol (estela especular)
    let halfVec = normalize(toEye + bloxdSunDirection());
    let specAlignment = clamp(dot(vec3f(0.0, 1.0, 0.0), halfVec), 0.0, 1.0);
    let reflectionChance = pow(specAlignment, 6.0) * SPARKLE_DENSITY * sunUp;

    // Semilla hash aleatoria por celda
    let worldCell = vec3i(localCell) + bloxdOriginOffset() * CELLS_PER_BLOCK;
    let h1 = cellHash(worldCell);
    let h2 = nextHash(h1);
    let h3 = nextHash(h2);

    if (hashUnit(h1) > reflectionChance) {
        return 0.0;
    }

    // Titileo suave con función senoidal
    let cycleRate = SPARKLE_SPEED + hashUnit(h2) * 1200.0;
    let pulse = 0.5 + 0.5 * sin(TAU * (bloxdTime() / bloxdTimeWrap * cycleRate + hashUnit(h3)));

    // Destello visible solo en el pico de la pulsación
    let flash = smoothstep(0.70, 0.98, pulse);
    return flash * SPARKLE_SHINE;
}