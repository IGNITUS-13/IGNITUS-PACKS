// Sun and shadow helpers shared by the terrain and water hooks.
// Uses Bloxd's voxel sky light combined with directional bounce for realistic shadows.

const SUN_EXPOSURE_FROM = 0.68;   // inicio de la penumbra en la luz del cielo
const SUN_EXPOSURE_TO = 0.95;     // cielo totalmente despejado

fn maxComponent(v: vec3f) -> f32 {
    return max(v.r, max(v.g, v.b));
}

// 0 en sombras cerradas, 1 bajo cielo abierto, con penumbra suave
fn sunExposure(skyLight: f32) -> f32 {
    return smoothstep(SUN_EXPOSURE_FROM, SUN_EXPOSURE_TO, skyLight);
}

// Intensidad solar según elevación sobre el horizonte
fn sunStrength() -> f32 {
    return smoothstep(0.0, 0.15, bloxdSunDirection().y);
}

// Factor de atardecer / amanecer (Golden Hour)
fn goldenHour() -> f32 {
    let height = bloxdSunDirection().y;
    return smoothstep(0.0, 0.08, height) * (1.0 - smoothstep(0.08, 0.38, height));
}

// Oclusión direccional ambiental: las caras que miran al cielo reciben más luz ambiental
// que las paredes o los techos interiores.
fn ambientOcclusionDirectional(normal: vec3f) -> f32 {
    return clamp(0.70 + 0.30 * normal.y, 0.55, 1.0);
}