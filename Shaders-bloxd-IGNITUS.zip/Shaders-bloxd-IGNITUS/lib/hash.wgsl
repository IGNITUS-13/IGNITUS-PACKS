// Integer hashes of world cells, for patterns fixed to the world. On whole world coordinates, so they never repeat or
// lose precision far from spawn.

fn mixBits(value: u32) -> u32 {
    var h = value;
    h ^= h >> 16u;
    h *= 0x7feb352du;
    h ^= h >> 15u;
    h *= 0x846ca68bu;
    h ^= h >> 16u;
    return h;
}

fn cellHash(cell: vec3i) -> u32 {
    let c = bitcast<vec3u>(cell);
    return mixBits((c.x * 0x8da6b343u) ^ (c.y * 0xd8163841u) ^ (c.z * 0xcb1ab31fu));
}

// A further independent hash from one already taken, for a second random value of the same cell.
fn nextHash(h: u32) -> u32 {
    return mixBits(h + 0x9e3779b9u);
}

// In [0, 1).
fn hashUnit(h: u32) -> f32 {
    return f32(h >> 8u) / 16777216.0;
}
